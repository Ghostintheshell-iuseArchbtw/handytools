package main

import (
	"context"
	"flag"
	"fmt"
	"log"
	"os"
	"os/signal"
	"syscall"
	"time"
	"webscraper_suite/scraper"
)

// PrintUsage prints usage information
func PrintUsage() {
	fmt.Println("WebScraper Suite - A versatile web scraping tool")
	fmt.Println("Version: 1.0.0")
	fmt.Println("\nUsage:")
	fmt.Println("  webscraper [command] [options]")
	fmt.Println("\nCommands:")
	fmt.Println("  scrape    - Perform a one-time scrape")
	fmt.Println("  schedule  - Schedule recurring scrapes")
	fmt.Println("  list      - List all scheduled jobs")
	fmt.Println("  version   - Show version information")
	fmt.Println("  help      - Show this help message")
	fmt.Println("\nOptions:")
	fmt.Println("  Run 'webscraper [command] -h' for command-specific options")
}

func main() {
	// Set up logging
	log.SetFlags(log.LstdFlags | log.Lshortfile)

	if len(os.Args) < 2 {
		PrintUsage()
		os.Exit(1)
	}

	// Handle version and help commands first
	switch os.Args[1] {
	case "version":
		fmt.Println("WebScraper Suite version 1.0.0")
		return
	case "help":
		PrintUsage()
		return
	}

	// Set up command flags
	scrapeCmd := flag.NewFlagSet("scrape", flag.ExitOnError)
	scheduleCmd := flag.NewFlagSet("schedule", flag.ExitOnError)
	listCmd := flag.NewFlagSet("list", flag.ExitOnError)

	// Common flags
	scrapeUrl := scrapeCmd.String("url", "", "URL to scrape")
	scrapeSelector := scrapeCmd.String("selector", "", "CSS selector to extract")
	scrapeFormat := scrapeCmd.String("format", "json", "Output format (json/csv)")
	scrapeVerbose := scrapeCmd.Bool("verbose", false, "Enable verbose logging")
	scrapeOutput := scrapeCmd.String("output", "", "Output file path")
	scrapeTimeout := scrapeCmd.Duration("timeout", 30*time.Second, "Scrape timeout duration")
	scrapeUserAgent := scrapeCmd.String("user-agent", "", "Custom User-Agent string")
	scrapeProxy := scrapeCmd.String("proxy", "", "Proxy URL (e.g., http://proxy:port)")
	scrapeDepth := scrapeCmd.Int("depth", 0, "Maximum crawl depth (0 for single page)")
	scrapeConcurrency := scrapeCmd.Int("concurrency", 1, "Number of concurrent requests")

	// Schedule-specific flags
	scheduleUrl := scheduleCmd.String("url", "", "URL to scrape")
	scheduleSelector := scheduleCmd.String("selector", "", "CSS selector to extract")
	scheduleFormat := scheduleCmd.String("format", "json", "Output format (json/csv)")
	scheduleVerbose := scheduleCmd.Bool("verbose", false, "Enable verbose logging")
	scheduleOutput := scheduleCmd.String("output", "", "Output file path")
	scheduleExpr := scheduleCmd.String("schedule", "", "Cron-style schedule expression")
	scheduleRetries := scheduleCmd.Int("retries", 3, "Number of retry attempts")
	scheduleRetryDelay := scheduleCmd.Duration("retry-delay", 5*time.Second, "Delay between retries")
	scheduleTimeout := scheduleCmd.Duration("timeout", 30*time.Second, "Scrape timeout duration")
	scheduleUserAgent := scheduleCmd.String("user-agent", "", "Custom User-Agent string")
	scheduleProxy := scheduleCmd.String("proxy", "", "Proxy URL (e.g., http://proxy:port)")
	scheduleDepth := scheduleCmd.Int("depth", 0, "Maximum crawl depth (0 for single page)")
	scheduleConcurrency := scheduleCmd.Int("concurrency", 1, "Number of concurrent requests")
	scheduleName := scheduleCmd.String("name", "", "Job name (defaults to URL if empty)")
	scheduleOutputDir := scheduleCmd.String("output-dir", "output", "Directory for output files")

	// List command flags
	listVerbose := listCmd.Bool("verbose", false, "Show detailed job information")

	// Parse the appropriate command
	switch os.Args[1] {
	case "scrape":
		scrapeCmd.Parse(os.Args[2:])
		if *scrapeUrl == "" || *scrapeSelector == "" {
			fmt.Println("Error: URL and selector must be provided")
			scrapeCmd.PrintDefaults()
			os.Exit(1)
		}

		// Create a context with timeout
		ctx, cancel := context.WithTimeout(context.Background(), *scrapeTimeout)
		defer cancel()

		// Set up headers
		headers := make(map[string]string)

		// Perform the scrape with context
		result, err := scraper.ScrapeWithContext(
			ctx,
			*scrapeUrl,
			*scrapeSelector,
			*scrapeFormat,
			*scrapeVerbose,
			*scrapeUserAgent,
			headers,
			*scrapeProxy,
			*scrapeDepth,
			*scrapeConcurrency,
		)

		if err != nil {
			log.Fatalf("Scrape failed: %v", err)
		}

		// If output file is specified, save the result
		if *scrapeOutput != "" {
			if err := scraper.SaveOutput(result, *scrapeOutput, *scrapeFormat); err != nil {
				log.Fatalf("Failed to save output: %v", err)
			}
			fmt.Printf("Results saved to %s\n", *scrapeOutput)
		} else {
			// Print result summary
			if sr, ok := result.(scraper.ScrapeResult); ok {
				fmt.Printf("Scrape completed: found %d items from %s\n", sr.Count, sr.URL)
			} else {
				fmt.Println("Scrape completed successfully")
			}
		}

	case "schedule":
		scheduleCmd.Parse(os.Args[2:])
		if *scheduleUrl == "" || *scheduleSelector == "" || *scheduleExpr == "" {
			fmt.Println("Error: URL, selector, and schedule must be provided")
			scheduleCmd.PrintDefaults()
			os.Exit(1)
		}

		// Create a new scheduler
		scheduler := scraper.NewScheduler()

		// Set output directory if specified
		if *scheduleOutputDir != "" {
			if err := scheduler.SetOutputDirectory(*scheduleOutputDir); err != nil {
				log.Fatalf("Failed to set output directory: %v", err)
			}
		}

		// Create job configuration
		config := scraper.DefaultSchedulerConfig()
		config.URL = *scheduleUrl
		config.Selector = *scheduleSelector
		config.Schedule = *scheduleExpr
		config.Format = *scheduleFormat
		config.Verbose = *scheduleVerbose
		config.Timeout = *scheduleTimeout
		config.RetryAttempts = *scheduleRetries
		config.RetryDelay = *scheduleRetryDelay
		config.OutputPath = *scheduleOutput
		config.UserAgent = *scheduleUserAgent
		config.ProxyURL = *scheduleProxy
		config.MaxDepth = *scheduleDepth
		config.Concurrency = *scheduleConcurrency

		// Use URL as job name if not specified
		jobName := *scheduleName
		if jobName == "" {
			jobName = *scheduleUrl
		}

		// Add the job
		jobID, err := scheduler.AddJob(jobName, config)
		if err != nil {
			log.Fatalf("Failed to schedule job: %v", err)
		}

		fmt.Printf("Job scheduled with ID: %d\n", jobID)
		scheduler.Start()

		// Set up signal handling for graceful shutdown
		sigChan := make(chan os.Signal, 1)
		signal.Notify(sigChan, syscall.SIGINT, syscall.SIGTERM)

		// Wait for termination signal
		<-sigChan
		fmt.Println("\nShutdown signal received, stopping scheduler...")
		scheduler.Stop()

	case "list":
		listCmd.Parse(os.Args[2:])

		// Create a scheduler to list jobs
		scheduler := scraper.NewScheduler()

		// Get all jobs
		jobs := scheduler.ListJobs()

		if len(jobs) == 0 {
			fmt.Println("No scheduled jobs found")
			return
		}

		fmt.Println("Scheduled jobs:")
		for id, name := range jobs {
			fmt.Printf("ID: %d, Name: %s\n", id, name)

			// Show detailed information if verbose flag is set
			if *listVerbose {
				status, found := scheduler.GetJobStatus(id)
				if found {
					fmt.Printf("  URL: %s\n", status.URL)
					fmt.Printf("  Schedule: %s\n", status.Schedule)
					fmt.Printf("  Last Run: %s\n", status.LastRun)
					fmt.Printf("  Next Run: %s\n", status.NextRun)
					fmt.Printf("  Success/Failure: %d/%d\n", status.SuccessCount, status.FailureCount)
					if status.LastError != "" {
						fmt.Printf("  Last Error: %s\n", status.LastError)
					}
				}
			}
		}

	default:
		fmt.Println("Unknown command:", os.Args[1])
		fmt.Println("Available commands: scrape, schedule, list, version, help")
		os.Exit(1)
	}
}
