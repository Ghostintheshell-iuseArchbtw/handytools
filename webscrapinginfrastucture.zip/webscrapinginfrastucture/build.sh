#!/bin/bash

set -e

echo "Setting up directories..."
mkdir -p scraper

# Initialize Go module if go.mod doesn't exist
if [ ! -f go.mod ]; then
  echo "Initializing Go module..."
  go mod init webscraper_suite
fi

echo "Installing dependencies..."
go get github.com/robfig/cron/v3
go get github.com/gocolly/colly
go mod tidy

# Fix import paths in main.go if needed
echo "Checking import paths..."
if grep -q "webscraper/scraper" main.go; then
  echo "Fixing import paths in main.go..."
  sed -i 's|webscraper/scraper|webscraper_suite/scraper|g' main.go
fi

# Check if SaveOutput is already defined in engine.go
if grep -q "func SaveOutput" scraper/engine.go; then
  echo "SaveOutput already defined in engine.go, removing from scheduler.go if present..."
  # Use sed to remove the SaveOutput function from scheduler.go if it exists
  sed -i '/\/\/ SaveOutput saves the scraping result to a file/,/^}/d' scraper/scheduler.go
else
  # Check if SaveOutput is missing from scheduler.go
  if ! grep -q "func SaveOutput" scraper/scheduler.go; then
    echo "Adding SaveOutput function to scheduler.go..."
    # First, ensure json is imported
    if ! grep -q "encoding/json" scraper/scheduler.go; then
      sed -i '1,/^import/s/^import (/import (\n\t"encoding\/json"/' scraper/scheduler.go
    fi
    
    cat >> scraper/scheduler.go << 'EOF'

// SaveOutput saves the scraping result to a file
func SaveOutput(result interface{}, path string, format string) error {
	file, err := os.Create(path)
	if err != nil {
		return fmt.Errorf("failed to create output file: %w", err)
	}
	defer file.Close()

	switch format {
	case "json":
		encoder := json.NewEncoder(file)
		encoder.SetIndent("", "  ")
		return encoder.Encode(result)
	case "csv":
		return writeCSV(file, result)
	default:
		return fmt.Errorf("unsupported format: %s", format)
	}
}
EOF
  fi
fi

# Fix ScheduleScrape function if it's incomplete
if grep -q "fmt.Println$" scraper/scheduler.go; then
  echo "Fixing incomplete ScheduleScrape function..."
  sed -i '/fmt.Println$/d' scraper/scheduler.go
  cat >> scraper/scheduler.go << 'EOF'
	fmt.Println("Scheduler started with job every", schedule)

	// Wait for termination signal
	<-sigChan
	fmt.Println("\nShutdown signal received, stopping scheduler...")
	scheduler.Stop()
}
EOF
fi

echo "Running tests..."
go test ./... || echo "Some tests failed, continuing with build..."

echo "Building Linux binary..."
GOOS=linux GOARCH=amd64 go build -o webscraper_linux main.go

echo "Building macOS binary (Intel)..."
GOOS=darwin GOARCH=amd64 go build -o webscraper_macos_intel main.go

echo "Building macOS binary (Apple Silicon)..."
GOOS=darwin GOARCH=arm64 go build -o webscraper_macos_arm64 main.go

echo "Building Windows binary..."
GOOS=windows GOARCH=amd64 go build -o webscraper_windows.exe main.go

echo "Build completed successfully!"
echo "Files generated:"
echo "- webscraper_linux"
echo "- webscraper_macos_intel"
echo "- webscraper_macos_arm64"
echo "- webscraper_windows.exe"
