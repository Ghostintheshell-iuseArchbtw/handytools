package scraper

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"net/url"
	"os"
	"strings"
	"time"

	"github.com/gocolly/colly"
	"github.com/gocolly/colly/extensions"
)

// ScrapeResult represents the result of a scraping operation
type ScrapeResult struct {
	URL       string      `json:"url"`
	Timestamp time.Time   `json:"timestamp"`
	Data      interface{} `json:"data"`
	Count     int         `json:"count"`
}

const (
	version = "1.0.0"
)

// PrintUsage prints usage information for the CLI
func PrintUsage() {
	fmt.Println("WebScraper Suite - A versatile web scraping tool")
	fmt.Println("Version:", version)
	fmt.Println("\nUsage:")
	fmt.Println("  webscraper [command] [options]")
	fmt.Println("\nCommands:")
	fmt.Println("  scrape    - Perform a one-time scrape")
	fmt.Println("  schedule  - Schedule recurring scrapes")
	fmt.Println("  list      - List all scheduled jobs")
	fmt.Println("  version   - Show version information")
	fmt.Println("  help      - Show this help message")
	fmt.Println("\nOptions:")
	fmt.Println("  Run 'webscraper [command] -h' for command-specific options")
}

// Scrape performs a basic web scrape operation
// Legacy function for backward compatibility
func Scrape(url, selector, format string, verbose bool) interface{} {
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	result, err := ScrapeWithContext(ctx, url, selector, format, verbose, "", nil, "", 0, 1)
	if err != nil {
		if verbose {
			log.Printf("Scraping failed: %v", err)
		}
		return nil
	}

	return result
}

// ScrapeWithContext performs a web scrape operation with context support
func ScrapeWithContext(
	ctx context.Context,
	targetURL string,
	selector string,
	format string,
	verbose bool,
	userAgent string,
	headers map[string]string,
	proxyURL string,
	maxDepth int,
	concurrency int,
) (interface{}, error) {
	// Validate URL
	if _, err := url.ParseRequestURI(targetURL); err != nil {
		return nil, fmt.Errorf("invalid URL: %w", err)
	}

	// Create a new collector
	c := colly.NewCollector(
		colly.MaxDepth(maxDepth),
		colly.Async(concurrency > 1),
	)

	// Set concurrency if async
	if concurrency > 1 {
		c.Limit(&colly.LimitRule{
			DomainGlob:  "*",
			Parallelism: concurrency,
		})
	}

	// Set user agent
	if userAgent != "" {
		c.UserAgent = userAgent
	} else {
		// Use random user agent
		extensions.RandomUserAgent(c)
	}

	// Set proxy if provided
	if proxyURL != "" {
		if err := c.SetProxy(proxyURL); err != nil {
			return nil, fmt.Errorf("failed to set proxy: %w", err)
		}
	}

	// Set custom headers
	if headers != nil {
		c.OnRequest(func(r *colly.Request) {
			for key, value := range headers {
				r.Headers.Set(key, value)
			}
		})
	}

	// Create a channel to receive results
	resultChan := make(chan interface{}, 1)
	errorChan := make(chan error, 1)

	// Handle errors
	c.OnError(func(r *colly.Response, err error) {
		if verbose {
			log.Printf("Request to %s failed: %v", r.Request.URL, err)
		}
		select {
		case errorChan <- fmt.Errorf("request failed: %w", err):
		default:
			// Channel already has an error
		}
	})

	// Handle successful response
	c.OnResponse(func(r *colly.Response) {
		if verbose {
			log.Printf("Received response from %s: status=%d, size=%d bytes",
				r.Request.URL, r.StatusCode, len(r.Body))
		}

		if r.StatusCode != http.StatusOK {
			select {
			case errorChan <- fmt.Errorf("received non-OK status code: %d", r.StatusCode):
			default:
				// Channel already has an error
			}
		}
	})

	// Extract data based on selector
	var items []string

	c.OnHTML(selector, func(e *colly.HTMLElement) {
		// Get text content
		text := strings.TrimSpace(e.Text)
		if text != "" {
			items = append(items, text)
			if verbose {
				log.Printf("Found item: %s", text)
			}
		}
	})

	// Set up completion callback
	c.OnScraped(func(r *colly.Response) {
		if verbose {
			log.Printf("Finished scraping %s", r.Request.URL)
		}

		// Create result object
		result := ScrapeResult{
			URL:       targetURL,
			Timestamp: time.Now(),
			Data:      items,
			Count:     len(items),
		}

		// Send result to channel
		select {
		case resultChan <- result:
		default:
			// Channel already has a result
		}
	})

	// Start scraping in a goroutine
	go func() {
		if err := c.Visit(targetURL); err != nil {
			select {
			case errorChan <- fmt.Errorf("failed to start scraping: %w", err):
			default:
				// Channel already has an error
			}
			return
		}

		// Wait for all requests to finish
		c.Wait()
	}()

	// Wait for result, error, or context cancellation
	select {
	case result := <-resultChan:
		return result, nil
	case err := <-errorChan:
		return nil, err
	case <-ctx.Done():
		return nil, ctx.Err()
	}
}

// SaveOutput saves the scraping result to a file
func SaveOutput(result interface{}, path string, format string) error {
	file, err := os.Create(path)
	if err != nil {
		return fmt.Errorf("failed to create output file: %w", err)
	}
	defer file.Close()

	switch format {
	case "json":
		encoder := json.NewEncoder(file)
		encoder.SetIndent("", "  ")
		return encoder.Encode(result)
	case "csv":
		return writeCSV(file, result)
	default:
		return fmt.Errorf("unsupported format: %s", format)
	}
}
