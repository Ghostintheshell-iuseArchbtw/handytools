package scraper

import (
	"io/ioutil"
	"os"
	"testing"
	"time"
)

func TestDefaultSchedulerConfig(t *testing.T) {
	config := DefaultSchedulerConfig()

	// Check default values
	if config.Timeout != 30*time.Second {
		t.Errorf("Expected default timeout to be 30s, got %v", config.Timeout)
	}

	if config.RetryAttempts != 3 {
		t.Errorf("Expected default retry attempts to be 3, got %d", config.RetryAttempts)
	}

	if config.RetryDelay != 5*time.Second {
		t.Errorf("Expected default retry delay to be 5s, got %v", config.RetryDelay)
	}

	if config.Format != "json" {
		t.Errorf("Expected default format to be 'json', got '%s'", config.Format)
	}

	if config.UserAgent != "WebScraperBot/1.0" {
		t.Errorf("Expected default user agent to be 'WebScraperBot/1.0', got '%s'", config.UserAgent)
	}

	if config.MaxDepth != 0 {
		t.Errorf("Expected default max depth to be 0, got %d", config.MaxDepth)
	}

	if config.Concurrency != 1 {
		t.Errorf("Expected default concurrency to be 1, got %d", config.Concurrency)
	}
}

func TestValidateConfig(t *testing.T) {
	// Valid config
	validConfig := SchedulerConfig{
		URL:           "https://example.com",
		Selector:      ".item",
		Schedule:      "0 * * * * *", // Changed to 6 fields (with seconds)
		Format:        "json",
		Timeout:       30 * time.Second,
		RetryAttempts: 3,
	}

	if err := ValidateConfig(validConfig); err != nil {
		t.Errorf("Expected valid config to pass validation, got error: %v", err)
	}

	// Test missing URL
	invalidConfig := validConfig
	invalidConfig.URL = ""
	if err := ValidateConfig(invalidConfig); err == nil {
		t.Error("Expected error for missing URL, got nil")
	}

	// Test missing selector
	invalidConfig = validConfig
	invalidConfig.Selector = ""
	if err := ValidateConfig(invalidConfig); err == nil {
		t.Error("Expected error for missing selector, got nil")
	}

	// Test missing schedule
	invalidConfig = validConfig
	invalidConfig.Schedule = ""
	if err := ValidateConfig(invalidConfig); err == nil {
		t.Error("Expected error for missing schedule, got nil")
	}

	// Test invalid schedule
	invalidConfig = validConfig
	invalidConfig.Schedule = "invalid"
	if err := ValidateConfig(invalidConfig); err == nil {
		t.Error("Expected error for invalid schedule, got nil")
	}

	// Test invalid format
	invalidConfig = validConfig
	invalidConfig.Format = "invalid"
	if err := ValidateConfig(invalidConfig); err == nil {
		t.Error("Expected error for invalid format, got nil")
	}

	// Test negative retry attempts
	invalidConfig = validConfig
	invalidConfig.RetryAttempts = -1
	if err := ValidateConfig(invalidConfig); err == nil {
		t.Error("Expected error for negative retry attempts, got nil")
	}

	// Test zero timeout
	invalidConfig = validConfig
	invalidConfig.Timeout = 0
	if err := ValidateConfig(invalidConfig); err == nil {
		t.Error("Expected error for zero timeout, got nil")
	}
}

func TestNewScheduler(t *testing.T) {
	scheduler := NewScheduler()

	if scheduler.cron == nil {
		t.Error("Expected cron to be initialized")
	}

	if scheduler.jobs == nil {
		t.Error("Expected jobs map to be initialized")
	}

	if scheduler.jobStatuses == nil {
		t.Error("Expected jobStatuses map to be initialized")
	}

	if scheduler.ctx == nil {
		t.Error("Expected context to be initialized")
	}

	if scheduler.cancel == nil {
		t.Error("Expected cancel function to be initialized")
	}

	if scheduler.logger == nil {
		t.Error("Expected logger to be initialized")
	}

	if scheduler.outputDir != "output" {
		t.Errorf("Expected default output directory to be 'output', got '%s'", scheduler.outputDir)
	}
}

func TestSetOutputDirectory(t *testing.T) {
	scheduler := NewScheduler()

	// Create a temporary directory
	tempDir, err := ioutil.TempDir("", "scheduler-test-")
	if err != nil {
		t.Fatalf("Failed to create temp directory: %v", err)
	}
	defer os.RemoveAll(tempDir)

	// Test setting output directory
	err = scheduler.SetOutputDirectory(tempDir)
	if err != nil {
		t.Errorf("SetOutputDirectory failed: %v", err)
	}

	if scheduler.outputDir != tempDir {
		t.Errorf("Expected output directory to be '%s', got '%s'", tempDir, scheduler.outputDir)
	}

	// Test creating a new directory
	newDir := tempDir + "/new-dir"
	err = scheduler.SetOutputDirectory(newDir)
	if err != nil {
		t.Errorf("SetOutputDirectory failed to create new directory: %v", err)
	}

	if scheduler.outputDir != newDir {
		t.Errorf("Expected output directory to be '%s', got '%s'", newDir, scheduler.outputDir)
	}

	// Check if directory was created
	if _, err := os.Stat(newDir); os.IsNotExist(err) {
		t.Errorf("Expected directory '%s' to exist", newDir)
	}
}

func TestAddJob(t *testing.T) {
	scheduler := NewScheduler()

	config := SchedulerConfig{
		URL:           "https://example.com",
		Selector:      ".item",
		Schedule:      "* * * * * *", // Changed from "* * * * *" to include seconds
		Format:        "json",
		Timeout:       30 * time.Second,
		RetryAttempts: 3,
	}

	// Add a job
	jobID, err := scheduler.AddJob("test-job", config)
	if err != nil {
		t.Fatalf("AddJob failed: %v", err)
	}

	// Check if job was added
	if len(scheduler.jobs) != 1 {
		t.Errorf("Expected 1 job, got %d", len(scheduler.jobs))
	}

	// Check if job status was created
	status, exists := scheduler.jobStatuses[jobID]
	if !exists {
		t.Errorf("Expected job status to exist for job ID %d", jobID)
	}

	if status.Name != "test-job" {
		t.Errorf("Expected job name to be 'test-job', got '%s'", status.Name)
	}

	if status.URL != config.URL {
		t.Errorf("Expected job URL to be '%s', got '%s'", config.URL, status.URL)
	}

	if status.Schedule != config.Schedule {
		t.Errorf("Expected job schedule to be '%s', got '%s'", config.Schedule, status.Schedule)
	}

	// Test adding a job with invalid config
	invalidConfig := config
	invalidConfig.URL = ""
	_, err = scheduler.AddJob("invalid-job", invalidConfig)
	if err == nil {
		t.Error("Expected error for invalid config, got nil")
	}
}

func TestRemoveJob(t *testing.T) {
	scheduler := NewScheduler()

	config := SchedulerConfig{
		URL:           "https://example.com",
		Selector:      ".item",
		Schedule:      "* * * * * *", // Changed from "* * * * *" to include seconds
		Format:        "json",
		Timeout:       30 * time.Second,
		RetryAttempts: 3,
	}

	// Add a job
	jobID, err := scheduler.AddJob("test-job", config)
	if err != nil {
		t.Fatalf("AddJob failed: %v", err)
	}

	// Remove the job
	removed := scheduler.RemoveJob(jobID)
	if !removed {
		t.Error("Expected RemoveJob to return true")
	}

	// Check if job was removed
	if len(scheduler.jobs) != 0 {
		t.Errorf("Expected 0 jobs, got %d", len(scheduler.jobs))
	}

	// Check if job status was removed
	_, exists := scheduler.jobStatuses[jobID]
	if exists {
		t.Error("Expected job status to be removed")
	}

	// Try to remove a non-existent job
	removed = scheduler.RemoveJob(9999)
	if removed {
		t.Error("Expected RemoveJob to return false for non-existent job")
	}
}

func TestGetJobStatus(t *testing.T) {
	scheduler := NewScheduler()

	config := SchedulerConfig{
		URL:           "https://example.com",
		Selector:      ".item",
		Schedule:      "* * * * * *", // Changed from "* * * * *" to include seconds
		Format:        "json",
		Timeout:       30 * time.Second,
		RetryAttempts: 3,
	}

	// Add a job
	jobID, err := scheduler.AddJob("test-job", config)
	if err != nil {
		t.Fatalf("AddJob failed: %v", err)
	}

	// Get job status
	status, exists := scheduler.GetJobStatus(jobID)
	if !exists {
		t.Error("Expected job status to exist")
	}

	if status.Name != "test-job" {
		t.Errorf("Expected job name to be 'test-job', got '%s'", status.Name)
	}

	// Try to get status for a non-existent job
	_, exists = scheduler.GetJobStatus(9999)
	if exists {
		t.Error("Expected GetJobStatus to return false for non-existent job")
	}
}

func TestGetAllJobStatuses(t *testing.T) {
	scheduler := NewScheduler()

	// Add multiple jobs
	configs := []struct {
		name string
		url  string
	}{
		{"job1", "https://example1.com"},
		{"job2", "https://example2.com"},
		{"job3", "https://example3.com"},
	}

	for _, cfg := range configs {
		config := SchedulerConfig{
			URL:           cfg.url,
			Selector:      ".item",
			Schedule:      "* * * * * *", // Run every second
			Format:        "json",
			Timeout:       30 * time.Second,
			RetryAttempts: 3,
		}

		_, err := scheduler.AddJob(cfg.name, config)
		if err != nil {
			t.Fatalf("AddJob failed for %s: %v", cfg.name, err)
		}
	}

	// Get all job statuses
	statuses := scheduler.GetAllJobStatuses()
	if len(statuses) != len(configs) {
		t.Errorf("Expected %d job statuses, got %d", len(configs), len(statuses))
	}

	// Check if all jobs are included
	jobNames := make(map[string]bool)
	for _, status := range statuses {
		jobNames[status.Name] = true
	}

	for _, cfg := range configs {
		if !jobNames[cfg.name] {
			t.Errorf("Expected job '%s' to be included in statuses", cfg.name)
		}
	}
}

func TestUpdateNextRunTimes(t *testing.T) {
	scheduler := NewScheduler()

	config := SchedulerConfig{
		URL:           "https://example.com",
		Selector:      ".item",
		Schedule:      "* * * * * *", // Run every second
		Format:        "json",
		Timeout:       30 * time.Second,
		RetryAttempts: 3,
	}

	// Add a job
	jobID, err := scheduler.AddJob("test-job", config)
	if err != nil {
		t.Fatalf("AddJob failed: %v", err)
	}

	// Start the scheduler to initialize next run times
	scheduler.Start()
	defer scheduler.Stop()

	// Update next run times
	scheduler.UpdateNextRunTimes()

	// Check if next run time was updated
	status, exists := scheduler.GetJobStatus(jobID)
	if !exists {
		t.Error("Expected job status to exist")
	}

	if status.NextRun.IsZero() {
		t.Error("Expected next run time to be set")
	}
}

func TestListJobs(t *testing.T) {
	scheduler := NewScheduler()

	// Add multiple jobs
	configs := []struct {
		name string
		url  string
	}{
		{"job1", "https://example1.com"},
		{"job2", "https://example2.com"},
		{"job3", "https://example3.com"},
	}

	for _, cfg := range configs {
		config := SchedulerConfig{
			URL:           cfg.url,
			Selector:      ".item",
			Schedule:      "* * * * * *", // Run every second
			Format:        "json",
			Timeout:       30 * time.Second,
			RetryAttempts: 3,
		}

		_, err := scheduler.AddJob(cfg.name, config)
		if err != nil {
			t.Fatalf("AddJob failed for %s: %v", cfg.name, err)
		}
	}

	// List jobs
	jobs := scheduler.ListJobs()
	if len(jobs) != len(configs) {
		t.Errorf("Expected %d jobs, got %d", len(configs), len(jobs))
	}

	// Check if all jobs are included
	jobNames := make(map[string]bool)
	for _, name := range jobs {
		jobNames[name] = true
	}

	for _, cfg := range configs {
		if !jobNames[cfg.name] {
			t.Errorf("Expected job '%s' to be included in jobs list", cfg.name)
		}
	}
}

func TestWriteCSV(t *testing.T) {
	// Test with ScrapeResult
	t.Run("ScrapeResult", func(t *testing.T) {
		result := ScrapeResult{
			URL:       "https://example.com",
			Timestamp: time.Now(),
			Count:     3,
			Data:      []string{"Item 1", "Item 2", "Item 3"},
		}

		tempFile, err := ioutil.TempFile("", "test-csv-*.csv")
		if err != nil {
			t.Fatalf("Failed to create temp file: %v", err)
		}
		defer os.Remove(tempFile.Name())
		defer tempFile.Close()

		err = writeCSV(tempFile, result)
		if err != nil {
			t.Fatalf("writeCSV failed: %v", err)
		}

		// Check if file has content
		fileInfo, err := os.Stat(tempFile.Name())
		if err != nil {
			t.Fatalf("Failed to stat output file: %v", err)
		}

		if fileInfo.Size() == 0 {
			t.Error("Output CSV file is empty")
		}
	})

	// Test with slice of maps
	t.Run("SliceOfMaps", func(t *testing.T) {
		data := []map[string]string{
			{"name": "Item 1", "value": "Value 1"},
			{"name": "Item 2", "value": "Value 2"},
			{"name": "Item 3", "value": "Value 3"},
		}

		tempFile, err := ioutil.TempFile("", "test-csv-*.csv")
		if err != nil {
			t.Fatalf("Failed to create temp file: %v", err)
		}
		defer os.Remove(tempFile.Name())
		defer tempFile.Close()

		err = writeCSV(tempFile, data)
		if err != nil {
			t.Fatalf("writeCSV failed: %v", err)
		}

		// Check if file has content
		fileInfo, err := os.Stat(tempFile.Name())
		if err != nil {
			t.Fatalf("Failed to stat output file: %v", err)
		}

		if fileInfo.Size() == 0 {
			t.Error("Output CSV file is empty")
		}
	})

	// Test with unsupported data type
	t.Run("UnsupportedType", func(t *testing.T) {
		data := 123 // Unsupported type

		tempFile, err := ioutil.TempFile("", "test-csv-*.csv")
		if err != nil {
			t.Fatalf("Failed to create temp file: %v", err)
		}
		defer os.Remove(tempFile.Name())
		defer tempFile.Close()

		err = writeCSV(tempFile, data)
		if err == nil {
			t.Error("Expected error for unsupported data type, got nil")
		}
	})
}
