package scraper

import (
	"context"
	"fmt"
	"time"
)

// MockScrapeWithContext is a mock implementation of ScrapeWithContext for testing
func MockScrapeWithContext(
	ctx context.Context,
	url string,
	selector string,
	format string,
	verbose bool,
	userAgent string,
	headers map[string]string,
	proxyURL string,
	maxDepth int,
	concurrency int,
) (interface{}, error) {
	// Check if context is already done
	select {
	case <-ctx.Done():
		return nil, ctx.Err()
	default:
		// Continue
	}

	// Simulate a successful scrape
	if url == "https://example.com" || url == "http://example.com" {
		return ScrapeResult{
			URL:       url,
			Timestamp: time.Now(),
			Count:     3,
			Data:      []string{"Item 1", "Item 2", "Item 3"},
		}, nil
	}

	// Simulate an error for specific URLs
	if url == "https://error.com" {
		return nil, fmt.Errorf("simulated error")
	}

	// Default response
	return ScrapeResult{
		URL:       url,
		Timestamp: time.Now(),
		Count:     0,
		Data:      []string{},
	}, nil
}

// Replace the real ScrapeWithContext with the mock for testing
func init() {
	// This is commented out because we don't want to actually replace the function
	// in the real code. In a real test setup, you would use dependency injection
	// or a similar pattern to inject the mock.
	//
	// ScrapeWithContext = MockScrapeWithContext
}
