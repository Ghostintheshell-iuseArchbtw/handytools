package scraper

import (
	"testing"
	"time"
)

func TestScrapeResult(t *testing.T) {
	// Create a ScrapeResult
	result := ScrapeResult{
		URL:       "https://example.com",
		Timestamp: time.Now(),
		Count:     3,
		Data:      []string{"Item 1", "Item 2", "Item 3"},
	}

	// Check URL
	if result.URL != "https://example.com" {
		t.Errorf("Expected URL to be 'https://example.com', got '%s'", result.URL)
	}

	// Check Count
	if result.Count != 3 {
		t.Errorf("Expected Count to be 3, got %d", result.Count)
	}

	// Check Data
	data, ok := result.Data.([]string)
	if !ok {
		t.Fatalf("Expected Data to be of type []string, got %T", result.Data)
	}

	expectedItems := []string{"Item 1", "Item 2", "Item 3"}
	if len(data) != len(expectedItems) {
		t.Fatalf("Expected %d items, got %d", len(expectedItems), len(data))
	}

	for i, item := range data {
		if item != expectedItems[i] {
			t.Errorf("Expected item %d to be '%s', got '%s'", i, expectedItems[i], item)
		}
	}
}
