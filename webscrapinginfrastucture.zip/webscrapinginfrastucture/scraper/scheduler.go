package scraper

import (
	"context"
	"encoding/csv"
	"fmt"
	"io"
	"log"
	"os"
	"os/signal"
	"path/filepath"
	"sync"
	"syscall"
	"time"

	"github.com/robfig/cron/v3"
)

// SchedulerConfig holds configuration for the scheduler
type SchedulerConfig struct {
	URL           string            // URL to scrape
	Selector      string            // CSS selector to extract
	Schedule      string            // Cron-style schedule expression
	Format        string            // Output format (json/csv)
	Verbose       bool              // Enable verbose logging
	Timeout       time.Duration     // Timeout for each scrape operation
	RetryAttempts int               // Number of retry attempts
	RetryDelay    time.Duration     // Delay between retries
	OutputPath    string            // Path to save output
	UserAgent     string            // Custom User-Agent string
	Headers       map[string]string // Custom HTTP headers
	ProxyURL      string            // Proxy URL if needed
	MaxDepth      int               // Maximum crawl depth (0 for single page)
	Concurrency   int               // Number of concurrent requests
}

// DefaultSchedulerConfig returns a default configuration
func DefaultSchedulerConfig() SchedulerConfig {
	return SchedulerConfig{
		Timeout:       30 * time.Second,
		RetryAttempts: 3,
		RetryDelay:    5 * time.Second,
		Format:        "json",
		UserAgent:     "WebScraperBot/1.0",
		Headers:       make(map[string]string),
		MaxDepth:      0,
		Concurrency:   1,
	}
}

// JobStatus represents the current status of a scheduled job
type JobStatus struct {
	ID              cron.EntryID
	Name            string
	URL             string
	Schedule        string
	LastRun         time.Time
	NextRun         time.Time
	SuccessCount    int
	FailureCount    int
	LastError       string
	LastRunDuration time.Duration
}

// Scheduler manages scheduled scraping jobs
type Scheduler struct {
	cron        *cron.Cron
	jobs        map[cron.EntryID]string
	jobStatuses map[cron.EntryID]*JobStatus
	mu          sync.RWMutex
	ctx         context.Context
	cancel      context.CancelFunc
	waitGroup   sync.WaitGroup
	logger      *log.Logger
	outputDir   string
}

// NewScheduler creates a new scheduler instance
func NewScheduler() *Scheduler {
	ctx, cancel := context.WithCancel(context.Background())
	return &Scheduler{
		cron:        cron.New(cron.WithSeconds()),
		jobs:        make(map[cron.EntryID]string),
		jobStatuses: make(map[cron.EntryID]*JobStatus),
		ctx:         ctx,
		cancel:      cancel,
		logger:      log.New(os.Stdout, "[Scheduler] ", log.LstdFlags),
		outputDir:   "output", // Default output directory
	}
}

// SetLogger sets a custom logger for the scheduler
func (s *Scheduler) SetLogger(logger *log.Logger) {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.logger = logger
}

// SetOutputDirectory sets the directory where output files will be saved
func (s *Scheduler) SetOutputDirectory(dir string) error {
	// Create the directory if it doesn't exist
	if err := os.MkdirAll(dir, 0755); err != nil {
		return fmt.Errorf("failed to create output directory: %w", err)
	}

	s.mu.Lock()
	defer s.mu.Unlock()
	s.outputDir = dir
	return nil
}

// ValidateConfig validates the scheduler configuration
func ValidateConfig(config SchedulerConfig) error {
	if config.URL == "" {
		return fmt.Errorf("URL cannot be empty")
	}

	if config.Selector == "" {
		return fmt.Errorf("selector cannot be empty")
	}

	if config.Schedule == "" {
		return fmt.Errorf("schedule expression cannot be empty")
	}

	// Validate cron expression with seconds support
	parser := cron.NewParser(cron.Second | cron.Minute | cron.Hour | cron.Dom | cron.Month | cron.Dow)
	_, err := parser.Parse(config.Schedule)
	if err != nil {
		return fmt.Errorf("invalid schedule expression: %w", err)
	}

	if config.Format != "json" && config.Format != "csv" {
		return fmt.Errorf("unsupported format: %s (supported: json, csv)", config.Format)
	}

	if config.RetryAttempts < 0 {
		return fmt.Errorf("retry attempts cannot be negative")
	}

	if config.Timeout <= 0 {
		return fmt.Errorf("timeout must be greater than zero")
	}

	return nil
}

// AddJob adds a new scraping job to the scheduler
func (s *Scheduler) AddJob(name string, config SchedulerConfig) (cron.EntryID, error) {
	if err := ValidateConfig(config); err != nil {
		return 0, err
	}

	s.mu.Lock()
	defer s.mu.Unlock()

	// Create job status
	jobStatus := &JobStatus{
		Name:     name,
		URL:      config.URL,
		Schedule: config.Schedule,
	}

	// Use jobID instead of id to avoid the undefined variable issue
	var jobID cron.EntryID

	// Define the job function
	jobFunc := func() {
		s.waitGroup.Add(1)
		defer s.waitGroup.Done()

		// Update job status
		s.mu.Lock()
		status := s.jobStatuses[jobID] // Now jobID is defined before use
		status.LastRun = time.Now()
		s.mu.Unlock()

		startTime := time.Now()

		// Create a context with timeout for this job
		jobCtx, cancel := context.WithTimeout(s.ctx, config.Timeout)
		defer cancel()

		if config.Verbose {
			s.logger.Printf("Starting scheduled job '%s' for URL: %s", name, config.URL)
		}

		// Attempt scraping with retries
		var result interface{}
		var scrapeErr error

		for attempt := 1; attempt <= config.RetryAttempts; attempt++ {
			result, scrapeErr = ScrapeWithContext(
				jobCtx,
				config.URL,
				config.Selector,
				config.Format,
				config.Verbose,
				config.UserAgent,
				config.Headers,
				config.ProxyURL,
				config.MaxDepth,
				config.Concurrency,
			)

			if scrapeErr == nil {
				break
			}

			if attempt < config.RetryAttempts {
				if config.Verbose {
					s.logger.Printf("Attempt %d failed: %v. Retrying in %v...", attempt, scrapeErr, config.RetryDelay)
				}
				select {
				case <-jobCtx.Done():
					scrapeErr = fmt.Errorf("job cancelled: %w", jobCtx.Err())
					return
				case <-time.After(config.RetryDelay):
					// Continue to next attempt
				}
			}
		}

		// Update job status with results
		s.mu.Lock()
		status.LastRunDuration = time.Since(startTime)
		if scrapeErr != nil {
			status.FailureCount++
			status.LastError = scrapeErr.Error()
		} else {
			status.SuccessCount++
			status.LastError = ""
		}
		s.mu.Unlock()

		if scrapeErr != nil {
			s.logger.Printf("Job '%s' failed after %d attempts: %v", name, config.RetryAttempts, scrapeErr)
			return
		}

		// Handle output
		outputPath := config.OutputPath
		if outputPath == "" && s.outputDir != "" {
			// Generate default output path if none specified
			timestamp := time.Now().Format("20060102_150405")
			filename := fmt.Sprintf("%s_%s.%s", name, timestamp, config.Format)
			outputPath = filepath.Join(s.outputDir, filename)
		}

		if outputPath != "" {
			if err := SaveOutput(result, outputPath, config.Format); err != nil {
				s.logger.Printf("Failed to save output for job '%s': %v", name, err)
			} else if config.Verbose {
				s.logger.Printf("Results saved to %s", outputPath)
			}
		}

		if config.Verbose {
			s.logger.Printf("Job '%s' completed successfully in %v", name, status.LastRunDuration)
		}
	}

	// Now assign the jobID
	var err error
	jobID, err = s.cron.AddFunc(config.Schedule, jobFunc)

	if err != nil {
		return 0, fmt.Errorf("failed to schedule job: %w", err)
	}

	// Store job information
	s.jobs[jobID] = name
	jobStatus.ID = jobID

	// Get next run time from cron entry
	entry := s.cron.Entry(jobID)
	if !entry.Next.IsZero() {
		jobStatus.NextRun = entry.Next
	}

	s.jobStatuses[jobID] = jobStatus

	return jobID, nil
}

// RemoveJob removes a job from the scheduler
func (s *Scheduler) RemoveJob(id cron.EntryID) bool {
	s.mu.Lock()
	defer s.mu.Unlock()

	if _, exists := s.jobs[id]; !exists {
		return false
	}

	s.cron.Remove(id)
	delete(s.jobs, id)
	delete(s.jobStatuses, id)
	return true
}

// GetJobStatus returns the status of a specific job
func (s *Scheduler) GetJobStatus(id cron.EntryID) (*JobStatus, bool) {
	s.mu.RLock()
	defer s.mu.RUnlock()

	status, exists := s.jobStatuses[id]
	if !exists {
		return nil, false
	}

	// Return a copy to avoid race conditions
	statusCopy := *status
	return &statusCopy, true
}

// GetAllJobStatuses returns the status of all jobs
func (s *Scheduler) GetAllJobStatuses() []*JobStatus {
	s.mu.RLock()
	defer s.mu.RUnlock()

	statuses := make([]*JobStatus, 0, len(s.jobStatuses))
	for _, status := range s.jobStatuses {
		// Return copies to avoid race conditions
		statusCopy := *status
		statuses = append(statuses, &statusCopy)
	}
	return statuses
}

// UpdateNextRunTimes updates the next run time for all jobs
func (s *Scheduler) UpdateNextRunTimes() {
	s.mu.Lock()
	defer s.mu.Unlock()

	for id, status := range s.jobStatuses {
		entry := s.cron.Entry(id)
		if !entry.Next.IsZero() {
			status.NextRun = entry.Next
		}
	}
}

// Start starts the scheduler
func (s *Scheduler) Start() {
	s.cron.Start()
	s.logger.Println("Scheduler started successfully")
}

// Stop stops the scheduler and waits for all jobs to complete
func (s *Scheduler) Stop() {
	s.logger.Println("Stopping scheduler...")
	s.cancel() // Cancel the context for all jobs
	ctx := s.cron.Stop()

	// Wait for cron jobs to finish
	<-ctx.Done()

	// Wait for our own jobs to finish with a timeout
	waitCh := make(chan struct{})
	go func() {
		s.waitGroup.Wait()
		close(waitCh)
	}()

	select {
	case <-waitCh:
		s.logger.Println("All jobs completed gracefully")
	case <-time.After(10 * time.Second):
		s.logger.Println("Some jobs did not complete within timeout")
	}

	s.logger.Println("Scheduler stopped")
}

// ListJobs returns a list of all scheduled jobs
func (s *Scheduler) ListJobs() map[cron.EntryID]string {
	s.mu.RLock()
	defer s.mu.RUnlock()

	// Return a copy to avoid race conditions
	result := make(map[cron.EntryID]string, len(s.jobs))
	for id, name := range s.jobs {
		result[id] = name
	}
	return result
}

// writeCSV writes the result as CSV
func writeCSV(w io.Writer, data interface{}) error {
	csvWriter := csv.NewWriter(w)
	defer csvWriter.Flush()

	// Handle ScrapeResult type
	if result, ok := data.(ScrapeResult); ok {
		// Write header
		if err := csvWriter.Write([]string{"URL", "Timestamp", "Item", "Index"}); err != nil {
			return err
		}

		// Write data rows
		if items, ok := result.Data.([]string); ok {
			for i, item := range items {
				row := []string{
					result.URL,
					result.Timestamp.Format(time.RFC3339),
					item,
					fmt.Sprintf("%d", i+1),
				}
				if err := csvWriter.Write(row); err != nil {
					return err
				}
			}
			return nil
		}
	}

	// Handle slice of maps
	if items, ok := data.([]map[string]string); ok {
		// Write header
		if len(items) > 0 {
			var headers []string
			for key := range items[0] {
				headers = append(headers, key)
			}
			if err := csvWriter.Write(headers); err != nil {
				return err
			}

			// Write rows
			for _, item := range items {
				var row []string
				for _, header := range headers {
					row = append(row, item[header])
				}
				if err := csvWriter.Write(row); err != nil {
					return err
				}
			}
		}
		return nil
	}

	return fmt.Errorf("data format not supported for CSV output")
}

// ScheduleScrape is the legacy function for backward compatibility
func ScheduleScrape(url, selector, schedule, format string, verbose bool) {
	scheduler := NewScheduler()

	config := DefaultSchedulerConfig()
	config.URL = url
	config.Selector = selector
	config.Schedule = schedule
	config.Format = format
	config.Verbose = verbose

	// Set up signal handling for graceful shutdown
	sigChan := make(chan os.Signal, 1)
	signal.Notify(sigChan, syscall.SIGINT, syscall.SIGTERM)

	_, err := scheduler.AddJob("default", config)
	if err != nil {
		log.Fatalf("Failed to schedule job: %v", err)
	}

	scheduler.Start()
	fmt.Println("Scheduler started with job every", schedule)

	// Wait for termination signal
	<-sigChan
	fmt.Println("\nShutdown signal received, stopping scheduler...")
	scheduler.Stop()
}
